classdef AggOperations < int32
    % Store all supported Agg Operations
    enumeration
        MEAN(0)
        MEDIAN(1)
        EACH(2)
    end
end